#include <bits/stdc++.h>

//adding ns3 modules
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/netanim-module.h"
#include "ns3/tcp-westwood.h"
#include "ns3/internet-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/packet-sink.h"
#include "ns3/tcp-hybla.h"
#include "ns3/tcp-congestion-ops.h"
#include "ns3/traced-value.h"
#include "ns3/tcp-yeah.h"
#include "ns3/log.h"
#include "ns3/tcp-scalable.h"
#include "ns3/sequence-number.h"
#include "ns3/traced-value.h"
#include "ns3/drop-tail-queue.h"
#include "ns3/enum.h"

using namespace ns3;
//adding standard requirements
using std::cout;
using std::endl;
using std::string;
using std::map;
using std::to_string;
using std::max;

NS_LOG_COMPONENT_DEFINE ("Case2");
map<string, uint> Failed_Packets_Map;
map<string, long double> Data_Rcv, maxxTP;
map<Address, long double> Dest_Data;


string DTR;
uint maxPacketSize, PortNo, Tot_Packets;
long double RunningTime;

int func(ns3::Ipv4Address str)
{
	// helper function for identifying source address
	if(str == "172.16.111.1") return 1;
	else if(str == "172.16.112.1") return 2;
	else if(str == "172.16.113.1") return 3;
	else return -1;
}


class Case2 : public Application
{
	public:
	  Case2 ();
	  virtual ~Case2();

	  void initiate (Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate);

	private:
	  virtual void StartApplication (void);
	  virtual void StopApplication (void);

	  void ScheduleTx (void);
	  void SendPacket (void);

	  Ptr<Socket> instance_socket;
	  Address instance_peer;
	  uint32_t instance_packetSize;
	  uint32_t instance_nPackets;
	  DataRate instance_dataRate;
	  EventId instance_sendEvent;
	  bool instance_running;
	  uint32_t instance_packetsSent;
};

Case2::Case2() : instance_socket(0),instance_peer(),instance_packetSize(0),instance_nPackets(0),instance_dataRate(0),instance_sendEvent(),instance_running(false),instance_packetsSent(0)
{
	//pass
}

Case2::~Case2()
{
	instance_socket = 0;
}

void Case2::initiate(Ptr<Socket> sock, Address addr, uint32_t pSize, uint32_t nPackets, DataRate dataRate)
{
	instance_socket = sock;instance_peer = addr;
	instance_nPackets = nPackets;
	instance_dataRate = dataRate;
	instance_packetSize = pSize;
	return; 
}


void Case2::StartApplication(void)
{
	instance_running = 1;instance_packetsSent = 0;
	instance_socket->Bind();
	instance_socket->Connect(instance_peer);
	SendPacket();
	return;
}

void Case2::StopApplication(void)
{
	instance_running = 0;
  	if(instance_sendEvent.IsRunning()!=0) Simulator::Cancel(instance_sendEvent);
  	if(instance_socket) instance_socket->Close();
    	return;
}

void Case2::SendPacket(void)
{
  	Ptr<Packet> packet = Create<Packet>(instance_packetSize);
  	instance_socket->Send(packet);
  	if (++instance_packetsSent<instance_nPackets) ScheduleTx();
    	return;
}

void Case2::ScheduleTx(void)
{
  	if (instance_running!=0)
    	{
      		Time tNext(Seconds((instance_packetSize*8)/static_cast<long double>(instance_dataRate.GetBitRate())));
      		instance_sendEvent = Simulator::Schedule(tNext,&Case2::SendPacket,this);
    	}
    	return; 
}


Ptr<Socket> FlowX(Address sinkAddress,Ptr<Node> src, Ptr<Node> dst,string type,long double st)
{
	if(type=="westwood")
	{
		Config::SetDefault ("ns3::TcpWestwood::ProtocolType", EnumValue (TcpWestwood::WESTWOODPLUS));
		Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue(TcpWestwood::GetTypeId()));
	}
	else if(type=="hybla")
	{
		Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue(TcpHybla::GetTypeId()));
	}
	else
	{
		st=0;
		Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue(TcpYeah::GetTypeId()));
	}

	PacketSinkHelper var("ns3::TcpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(),PortNo));
	ApplicationContainer Sink_Container = var.Install(dst);
	Sink_Container.Start(Seconds(st));Sink_Container.Stop(Seconds(st + RunningTime));
	
	Ptr<Socket> TcpSocket = Socket::CreateSocket(src,TcpSocketFactory::GetTypeId());
	Ptr<Case2> app = CreateObject<Case2>();

	app->initiate(TcpSocket, sinkAddress,maxPacketSize,Tot_Packets,DataRate(DTR));
	src->AddApplication(app);
	app->SetStartTime(Seconds(st));app->SetStopTime(Seconds(st + RunningTime));
	return TcpSocket;
}

void Packet_Drop_Trigger(string var) 
{
	Failed_Packets_Map[var]=Failed_Packets_Map[var]+1;
	return;
}

void Conges_Window_writefile(FILE *fp, long double st, uint old, uint neww) 
{
	string x1 = to_string(Simulator::Now().GetSeconds() - st);
	string x2 = to_string(neww);
  	fprintf(fp,"%s,%s\n",x1.c_str(),x2.c_str());
  	return;
}

void Goodput_writefile(FILE *fp,long double st,string type,Ptr<const Packet> pckt, const Address& address)
{
	Dest_Data[address] = Dest_Data[address] + pckt->GetSize();
	long double temp = Dest_Data[address];
	long double neww = ((temp*8.0)/1024)/(Simulator::Now().GetSeconds() - st);
	string x1 = to_string(Simulator::Now().GetSeconds() - st);
	string x2 = to_string(neww);
  	fprintf(fp,"%s,%s\n",x1.c_str(),x2.c_str());
  	return;
}


void Throughput_writefile(FILE *fp,long double st,string type,Ptr<const Packet> pckt,Ptr<Ipv4> ipv4,uint interface) 
{

	if(maxxTP.find(type) == maxxTP.end()) maxxTP[type] = 0;
	Data_Rcv[type] = Data_Rcv[type] + pckt->GetSize();
	long double neww = (((Data_Rcv[type] * 8.0) / 1024)/(Simulator::Now().GetSeconds()-st));
	string x1 = to_string(Simulator::Now().GetSeconds() - st);
	string x2 = to_string(neww);
  	fprintf(fp,"%s,%s\n",x1.c_str(),x2.c_str());
	maxxTP[type] = max(maxxTP[type],neww);
	return;
}

long double start_time = 0;

void Configg(NodeContainer node,Ipv4InterfaceContainer IpInterface,int PortNo,int a,int b,string type,FILE* fp1, FILE* fp2,FILE* fp3,string t1,string t2,int RunningTime)
{
	Ptr<Socket> Sock = FlowX(InetSocketAddress(IpInterface.GetAddress(0),PortNo),node.Get(a),node.Get(b),type,start_time);
	Config::Connect(t1, MakeBoundCallback(&Goodput_writefile,fp1,start_time));
	Config::Connect(t2, MakeBoundCallback(&Throughput_writefile,fp2,start_time));
	Sock->TraceConnectWithoutContext("Drop", MakeBoundCallback(&Packet_Drop_Trigger, type));
	Sock->TraceConnectWithoutContext("CongestionWindow", MakeBoundCallback(&Conges_Window_writefile, fp3,start_time));
  	return;
}

int main(void)
{
  Tot_Packets = 1000000; // Total packets to be sent
  maxPacketSize = 1.3 * (int)pow(2,10); //Packet Size = 1.3 KB
  PortNo = 6000; // Port Number through which communiction happens
  DTR = "20Mbps"; // DATA TRANSFER RATE
  RunningTime = 1000; // Duration of Comminication

  PointToPointHelper RouterToRouter, DeviceToRouter;
//setting the attributes of Device to Router Line as per assignment
  DeviceToRouter.SetChannelAttribute("Delay", StringValue("20ms"));
  DeviceToRouter.SetDeviceAttribute("DataRate", StringValue("100Mbps"));
  string BDP = "1503p"; // BDP = 20ms * 10M0bps, QueueSize = BDP/1.3KB, 
  DeviceToRouter.SetQueue ("ns3::DropTailQueue<Packet>", "MaxSize", QueueSizeValue (QueueSize (BDP))); // p stands for packets
//setting the attributes of Router to Router Line as per assignment
  RouterToRouter.SetChannelAttribute("Delay", StringValue("50ms"));
  RouterToRouter.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  BDP = "376p"; // BDP = 50ms * 10Mbps, QueueSize = BDP/1.3KB
  RouterToRouter.SetQueue ("ns3::DropTailQueue<Packet>", "MaxSize", QueueSizeValue (QueueSize (BDP))); // p stands for packets
  
  NodeContainer node;
  node.Create(8); // 6(end devices) + 2(routers)
  cout << "Nodes Created" << endl;
 
/*
    
    Node Framework
    
    0-                 -5
      -               - 
    1 - - 3 - - - 4 - - 6 
      -               -
    2-                 -7
    
    Node3 and Node4 represents the Router1(R1) and Router2(R2) respectively
    Node0, Node5 - TCP YeAH
    Node1, Node6 - TCP Hybla
    Node2, Node7 - TCP Westwood+

*/
InternetStackHelper stackInternet;stackInternet.Install(node);
Ipv4AddressHelper IP_Add_Helper;
Ptr<RateErrorModel> del=CreateObjectWithAttributes<RateErrorModel>("ErrorRate",DoubleValue(0.00001));

  // There are 7 links

//Node0 to Node3 (Router 1)
  NodeContainer YeAH_N0_R1 = NodeContainer(node.Get(0), node.Get(3));
  NetDeviceContainer NDC_YeAH_N0_R1 = DeviceToRouter.Install(YeAH_N0_R1);NDC_YeAH_N0_R1.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue(del));
  IP_Add_Helper.SetBase ("172.16.111.0", "255.255.255.0");
  Ipv4InterfaceContainer IP_YeAH_N0_R1 = IP_Add_Helper.Assign(NDC_YeAH_N0_R1);
//Node1 to Node3 (Router 1)
  NodeContainer Hybla_N1_R1 = NodeContainer(node.Get(1), node.Get(3));
  NetDeviceContainer NDC_Hybla_N1_R1 = DeviceToRouter.Install(Hybla_N1_R1);NDC_Hybla_N1_R1.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue(del));
  IP_Add_Helper.SetBase ("172.16.112.0", "255.255.255.0");
  Ipv4InterfaceContainer IP_Hybla_N1_R1 = IP_Add_Helper.Assign(NDC_Hybla_N1_R1);
//Node2 to Node3 (Router 1)
  NodeContainer WestWood_N2_R1 = NodeContainer(node.Get(2), node.Get(3));
  NetDeviceContainer NDC_WestWood_N2_R1 = DeviceToRouter.Install(WestWood_N2_R1);NDC_WestWood_N2_R1.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue(del));
  IP_Add_Helper.SetBase ("172.16.113.0", "255.255.255.0");
  Ipv4InterfaceContainer IP_WestWood_N2_R1 = IP_Add_Helper.Assign(NDC_WestWood_N2_R1);
//Node5 to Node4 (Router 2)
  NodeContainer YeAH_N5_R2 = NodeContainer(node.Get(5), node.Get(4));
  NetDeviceContainer NDC_YeAH_N5_R2 = DeviceToRouter.Install(YeAH_N5_R2);NDC_YeAH_N5_R2.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue(del));
  IP_Add_Helper.SetBase ("172.16.115.0", "255.255.255.0");
  Ipv4InterfaceContainer IP_YeAH_N5_R2 = IP_Add_Helper.Assign(NDC_YeAH_N5_R2);
//Node6 to Node4 (Router 2)
  NodeContainer Hybla_N6_R2 = NodeContainer(node.Get(6), node.Get(4));
  NetDeviceContainer NDC_Hybla_N6_R2 = DeviceToRouter.Install(Hybla_N6_R2);NDC_Hybla_N6_R2.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue(del));
  IP_Add_Helper.SetBase ("172.16.116.0", "255.255.255.0");
  Ipv4InterfaceContainer IP_Hybla_N6_R2 = IP_Add_Helper.Assign(NDC_Hybla_N6_R2);
//Node7 to Node4 (Router 2)
  NodeContainer WestWood_N7_R2 = NodeContainer(node.Get(7), node.Get(4));
  NetDeviceContainer NDC_WestWood_N7_R2 = DeviceToRouter.Install(WestWood_N7_R2);NDC_WestWood_N7_R2.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue(del));
  IP_Add_Helper.SetBase ("172.16.117.0", "255.255.255.0");
  Ipv4InterfaceContainer IP_WestWood_N7_R2 = IP_Add_Helper.Assign(NDC_WestWood_N7_R2);
//Node3 (Router 1) to NodIP (Router 2)
  NodeContainer R1_R2 = NodeContainer(node.Get(3), node.Get(4));NetDeviceContainer NDC_R1_R2 = RouterToRouter.Install(R1_R2);
  IP_Add_Helper.SetBase ("172.16.114.0", "255.255.255.0");
  Ipv4InterfaceContainer IP_R1_R2 = IP_Add_Helper.Assign(NDC_R1_R2);

  cout << "Connections Made" << endl;
//file pointers for Congestion Window
  FILE *yeAH_CW_FP = fopen("Q2_yeAH_CongesWindow.csv", "w");
  FILE *hybla_CW_FP = fopen("Q2_hybla_CongesWindow.csv", "w");
  FILE *west_CW_FP = fopen("Q2_WestWood+_CongesWindow.csv", "w");
//file pointers for ThroughPut 
  FILE *yeAH_TP_FP = fopen("Q2_yeAH_ThroughPut.csv", "w");
  FILE *hybla_TP_FP = fopen("Q2_hybla_ThroughPut.csv", "w");
  FILE *west_TP_FP = fopen("Q2_WestWood+_ThroughPut.csv", "w");
//file pointers for GoodPut  
  FILE *yeAH_GP_FP = fopen("Q2_yeAH_GoodPut.csv", "w");
  FILE *hybla_GP_FP = fopen("Q2_hybla_GoodPut.csv", "w");
  FILE *west_GP_FP = fopen("Q2_WestWood+_GoodPut.csv", "w");



  Configg(node,IP_YeAH_N5_R2,PortNo,0,5,"yeah",yeAH_GP_FP,yeAH_TP_FP,yeAH_CW_FP,"/NodeList/5/ApplicationList/0/$ns3::PacketSink/Rx","/NodeList/5/$ns3::Ipv4L3Protocol/Rx",RunningTime);
  Configg(node,IP_Hybla_N6_R2,PortNo,1,6,"hybla",hybla_GP_FP,hybla_TP_FP,hybla_CW_FP,"/NodeList/6/ApplicationList/0/$ns3::PacketSink/Rx","/NodeList/6/$ns3::Ipv4L3Protocol/Rx",RunningTime);
  Configg(node,IP_WestWood_N7_R2,PortNo,2,7,"westwood",west_GP_FP,west_TP_FP,west_CW_FP,"/NodeList/7/ApplicationList/0/$ns3::PacketSink/Rx","/NodeList/7/$ns3::Ipv4L3Protocol/Rx",RunningTime);

  start_time += RunningTime;

  	Ipv4GlobalRoutingHelper::PopulateRoutingTables();
	FlowMonitorHelper helper;
	Ptr<FlowMonitor> flowMonitorPtr = helper.InstallAll();

 	Simulator::Stop(Seconds(start_time));
	Simulator::Run();
	cout << "Simulator Started Successfully" << endl; 

	flowMonitorPtr->CheckForLostPackets();
	Ptr<Ipv4FlowClassifier> FlowClass = DynamicCast<Ipv4FlowClassifier>(helper.GetClassifier());
	
	cout << "*********************************************************************************************" << endl;

	map<FlowId, FlowMonitor::FlowStats> MapInfo = flowMonitorPtr->GetFlowStats();
	map<FlowId, FlowMonitor::FlowStats>::const_iterator it = MapInfo.begin(); 
	
	// We will now print the Statistics of the different TCP Flows
	for(it=MapInfo.begin();it!=MapInfo.end();it++) 
	{
	
	    Ipv4FlowClassifier::FiveTuple ClassType = FlowClass->FindFlow(it->first);
	    switch(func(ClassType.sourceAddress))
	    {
	    	case 1:
	    		{
	    			// case handling TCP-YeAH
		    		cout << "CASE1: TCP-YeAH"  <<  endl;
				cout << "Flow ID : " << (to_string(it->first)) << endl;
				cout << "Source Address : " << ClassType.sourceAddress << endl;
				cout << "Destination Address : " << ClassType.destinationAddress << endl;
				long long int temp1 = 1000000;
				cout << "Total Packets Sent : " << temp1 << endl;
				long long int temp2 = stoll(to_string(Tot_Packets - it->second.lostPackets)); 
				cout << "Total Packets Received = " << temp2 << endl;
				cout << "Total Packets Lost = " <<  temp1-temp2 << endl;
				cout << "Packets Lost due to Buffer Overflow = " << (to_string(Failed_Packets_Map["yeah"])).c_str() << endl;
				cout << "Packets Lost due to Network Congestion = " << (to_string(it->second.lostPackets - Failed_Packets_Map["yeah"])).c_str() << endl;
				cout << "Maximum ThroughPut Obtained = "<< maxxTP["/NodeList/5/$ns3::Ipv4L3Protocol/Rx"] << " kbps" << endl;
				cout << "*********************************************************************************************" << endl;	
			break;
			} 
	    	case 2:
	    		{
	    			// case handling TCP-Hybla
		    		cout << "CASE2: TCP-Hybla"  <<  endl;
				cout << "Flow ID : " << (to_string(it->first)) << endl;
				cout << "Source Address : " << ClassType.sourceAddress << endl;
				cout << "Destination Address : " << ClassType.destinationAddress << endl;
				long long int temp3 = 1000000;
				cout << "Total Packets Sent : " << temp3 << endl;
				long long int temp4 = stoll(to_string(Tot_Packets - it->second.lostPackets)); 
				cout << "Total Packets Received = " << temp4 << endl;
				cout << "Total Packets Lost = " <<  temp3-temp4 << endl;
				cout << "Packets Lost due to Buffer Overflow = " << (to_string(Failed_Packets_Map["hybla"])).c_str() << endl;
				cout << "Packets Lost due to Network Congestion = " << (to_string(it->second.lostPackets - Failed_Packets_Map["hybla"])).c_str() << endl;
				cout << "Maximum ThroughPut Obtained = "<< maxxTP["/NodeList/6/$ns3::Ipv4L3Protocol/Rx"] << " kbps" << endl;
				cout << "*********************************************************************************************" << endl;
				break;
			}
		case 3:
			{
				// case handling TCP-Westwood+
				cout << "CASE3: TCP-Westwood+"  <<  endl;
				cout << "Flow ID : " << (to_string(it->first)) << endl;
				cout << "Source Address : " << ClassType.sourceAddress << endl;
				cout << "Destination Address : " << ClassType.destinationAddress << endl;
				long long int temp5 = 1000000;
				cout << "Total Packets Sent : " << temp5 << endl;
				long long int temp6 = stoll(to_string(Tot_Packets- it->second.lostPackets)); 
				cout << "Total Packets Received = " << temp6 << endl;
				cout << "Total Packets Lost = " <<  temp5-temp6 << endl;
				cout << "Packets Lost due to Buffer Overflow = " << (to_string(Failed_Packets_Map["westwood"])).c_str() << endl;
				cout << "Packets Lost due to Network Congestion = " << (to_string(it->second.lostPackets - Failed_Packets_Map["westwood"])).c_str() << endl;
				cout << "Maximum ThroughPut Obtained = "<< maxxTP["/NodeList/7/$ns3::Ipv4L3Protocol/Rx"] << " kbps" << endl;
				cout << "*********************************************************************************************" << endl;
				break;
			}
			
	    	default: 
	    		break;
	    }
	    
	}

	Simulator::Destroy(); // End the simulator
	cout << "Simulator Ended" << endl;
	return 0;

}
