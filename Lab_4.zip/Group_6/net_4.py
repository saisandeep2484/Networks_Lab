import csv
import numpy as np
import matplotlib.pyplot as plt 

# Congestion Window
for j in range(1,3):
    #files name format : "Q{1/2}_{'hybla'/'WestWood+'/'yeAH'}_CongesWindow.csv"
    files=['hybla','WestWood+','yeAH']
    for i in files:
        #reading the csv files generated for congestion window
        with open('Q'+str(j)+'_'+str(i)+'_CongesWindow.csv') as file:
            reader = csv.reader(file,quoting=csv.QUOTE_NONNUMERIC)
            count=0
            time=[]
            Conges_Window=[]
            for row in reader:
                time.append(row[0])
                Conges_Window.append(row[1])
            
            #plotting the size vs time graph for congestion window 
            x = np.array(time)  
            y = np.array(Conges_Window) 
            plt.title("TCP-"+str(i)+" Congestion Window")  
            plt.xlabel("Time(in seconds)")  
            plt.ylabel("Size(in bytes)")  
            plt.plot(x, y, color ="red")
            plt.grid()  
            plt.show()

#Throughput
for j in range(1,3):
    #files name format : "Q{1/2}_{'hybla'/'WestWood+'/'yeAH'}_ThroughPut.csv"
    files=['hybla','WestWood+','yeAH']
    for i in files:
        #reading the csv files generated for ThroughPut
        with open('Q'+str(j)+'_'+str(i)+'_ThroughPut.csv') as file:
            reader = csv.reader(file,quoting=csv.QUOTE_NONNUMERIC)
            count=0
            time=[]
            Conges_Window=[]
            for row in reader:
                time.append(row[0])
                Conges_Window.append(row[1])
            
            #plotting the speed vs time graph for ThroughPut 
            x = np.array(time)  
            y = np.array(Conges_Window) 
            plt.title("TCP-"+str(i)+" ThroughPut")  
            plt.xlabel("Time(in seconds)")  
            plt.ylabel("Speed(in Kbps)")  
            plt.plot(x, y, color ="red")
            plt.grid()  
            plt.show()

#GoodPut
for j in range(1,3):
    #files name format : "Q{1/2}_{'hybla'/'WestWood+'/'yeAH'}_GoodPut.csv"
    files=['hybla','WestWood+','yeAH']
    for i in files:
        #reading the csv files generated for GoodPut
        with open('Q'+str(j)+'_'+str(i)+'_GoodPut.csv') as file:
            reader = csv.reader(file,quoting=csv.QUOTE_NONNUMERIC)
            count=0
            time=[]
            Conges_Window=[]
            for row in reader:
                time.append(row[0])
                Conges_Window.append(row[1])
            
            #plotting the speed vs time graph for GoodPut
            x = np.array(time)  
            y = np.array(Conges_Window) 
            plt.title("TCP-"+str(i)+" GoodPut")  
            plt.xlabel("Time(in seconds)")  
            plt.ylabel("Speed(in Kbps)")  
            plt.plot(x, y, color ="red")
            plt.grid()  
            plt.show()
