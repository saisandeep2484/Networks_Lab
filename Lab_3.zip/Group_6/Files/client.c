#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/socket.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <string.h>

#define MAX_MSG_SIZE 512

void terminate_msg(void)
{
  //message printed before termination of program
  
  printf("The Program Will Now Terminate\n");
  return;
}


void cmd_argm_format(void)
{
  //message printed for specifying correct format for command line arguments
  
  printf("Please provide the Host IP Address and the Port Number as follows (in the command line):\n");
  printf("./client Host_IP_Addr Port_No\n");
  printf("Refer to ReadMe File for more details\n");
  return;

}

char* rcv(int sock) 	
{
  //function for recieving message from server
  
  int sz = 0;
  read(sock, &sz, sizeof(int));// string size is initially recieved, followed by the string
  int msg_sz = sz*sizeof(char);
  char *msg = (char*)malloc(msg_sz);
  read(sock, msg, msg_sz);
  msg[sz] = '\0';
  return msg;
}

void snd(int sock, char *msg) 			
{
    //function for sending message to server
    
    int sz = strlen(msg);
    write(sock, &sz, sizeof(int));
    int msg_sz = sz*sizeof(char);
    write(sock, msg, msg_sz);
    
    // first size is sent, then the string is sent, so that recieving becomes simple
}


int main(int argc,char** argv)
{
  if(argc<3)
  {
    // to handle improper command line arguments
    
    printf("Port Number or Host Address not provided in the command line\n");
    cmd_argm_format();
    terminate_msg();
    exit(0);  //program terminated
  }
  
  if(argc>3)
  {
    // to handle improper command line arguments
    
    printf("Extra Information Provided or the Information Provided is not in Proper Format (in the command line)\n");
    cmd_argm_format();
    terminate_msg();
    exit(0);   //program terminated
  }
  
  int Port_No = atoi(argv[2]);       //Server Port Number
  char* Host_IP_Addr = argv[1];      // Server IP Address
  printf("Host IP Address and Port No. Provided Successfully Accepted\n");
  
  int sock = 0;
  sock = socket(AF_INET, SOCK_STREAM, 0);  
   
  //The above call makes a stream socket(Using TCP Protocol)
  // AF_INET designates that the Address Family is Internet Protocol
  // SOCK_STREAM specifies that the socket is a TCP Socket
  
  if(sock<0)
  {
    // To check for errors while creating the socket
    printf("Error while Creating Socket\n");
    shutdown(sock,SHUT_WR);    //to close socket gracefully
    printf("\nSocket Closed Gracefully.\n");
    terminate_msg();
    exit(0);   //program terminated
  }
  
  struct sockaddr_in add = {0};                          //inbuilt data structure in header file <netinet/in.h>
  add.sin_addr.s_addr = inet_addr(Host_IP_Addr);         //specifying the fields in the struct
  add.sin_port = htons(Port_No);                         //specifying the fields in the struct
  add.sin_family = AF_INET;                              //specifying the fields in the struct
  
  
  int flag = connect(sock,(struct sockaddr*)&add,sizeof(add));        //connecting to the server
  if(flag<0)
  {
    // to check if the connection to the server was made properly
    printf("Connection Not Successful\n");
    shutdown(sock,SHUT_WR);    //to close socket gracefully
    printf("\nSocket Closed Gracefully.\n");
    terminate_msg();
    exit(0);   //program terminated
  }
  
  printf("Successfully Connected to the Bank Server\n");      //server connection is succesful
  char* server_reply = malloc(MAX_MSG_SIZE * sizeof(char));   //buffer for storing incoming msg
  char* user_name = malloc(MAX_MSG_SIZE * sizeof(char));      //buffer for stroing username
  int cn = 0;
  while(1)
  {
    if(cn==0) 
    {
    	//client sends username to server 
    	server_reply = rcv(sock);
    	printf("%s \n",server_reply);
    	char* client_msg = malloc(MAX_MSG_SIZE * sizeof(char));     // buffer for storing outgoing msg
    	scanf("%s",client_msg);                                     // read client message from the terminal
    	user_name = client_msg;                                      // username stored for future reference 
    	snd(sock,client_msg);
    	cn = 1;
    	printf("\n......................PROCESSING.............................\n\n");
    	continue;
    }
    else if(cn==1) 
    {
    	//client sends password to server 
    	server_reply = rcv(sock);
    	printf("Hello %s , %s \n",user_name,server_reply);
    	char* client_msg = malloc(MAX_MSG_SIZE * sizeof(char));     // buffer for storing outgoing msg
    	scanf("%s",client_msg);                                     // read client message from the terminal 
    	snd(sock,client_msg);
    	cn = 2;
    	printf("\n......................PROCESSING.............................\n\n");
    	continue;
    }
    
    //Checking User Validity 
    server_reply = rcv(sock); //recieve the message from server
    if(strcmp("Invalid Login Details",server_reply)==0)
    {
      printf("Invalid Login (Username or Password Wrong)\n");
      server_reply = rcv(sock); // update message if server sends Invalid Login
    }
    else
    {
    	//User Authenticated
    	if(cn==2) printf("\nUser Successfully Authenticated. \n\n");

    }
    
    //User has been authenticated
    printf("%s, Please refer to the below Reply/Message from Server:---\n\n",user_name);
    printf("%s \n(You Can Type 'end' to close the connection)\n",server_reply); //print main menu/server messages
    
    char* client_msg = malloc(MAX_MSG_SIZE * sizeof(char));     // buffer for storing outgoing msg
    scanf("%s",client_msg);                                     // read client message from the terminal 
    snd(sock,client_msg);                                       // send client message to server   
    
    if(client_msg[0] == 'e' && client_msg[1] == 'n' && client_msg[2] == 'd' && client_msg[3] == '\0')    // if client wants to close the connection, he will type exit
    {
      printf("\nTransaction Complete. Thank You.\n");
      shutdown(sock,SHUT_WR);    //to close socket gracefully
      printf("\nSocket Closed Gracefully.\n");
      terminate_msg();
      break;
    }
    printf("\n......................PROCESSING.............................\n\n");
    cn+=1;

  }
  return 0;
}

