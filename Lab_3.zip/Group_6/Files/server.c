#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/socket.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <string.h>
#include <time.h>

#define MAX_MSG_SIZE 512

void terminate_msg(void)
{
  //message printed before termination of program
  
  printf("The Program Will Now Terminate\n");
  return;
}

void cmd_argm_format(void)
{
  //message printed for specifying correct format for command line arguments
  
  printf("Please provide the Port Number as follows (in the command line):\n");
  printf("./server Port_No\n");
  printf("Refer to ReadMe File for more details\n");
  return;

}

struct User
{				
    // Stores the Current userID/username and its type[A/C/P]
    char userID[100];char t;
};


char* rcv(int sock) 	
{
  //function for recieving message from client
  
  int sz = 0;
  read(sock, &sz, sizeof(int));// string size is initially recieved, followed by the string
  int msg_sz = sz*sizeof(char);
  char *msg = (char*)malloc(msg_sz);
  read(sock, msg, msg_sz);
  msg[sz] = '\0';
  
  if(msg[0] == 'e' && msg[1] == 'n' && msg[2] == 'd' && msg[3] == '\0')    // if client wants to close the connection, he will type exit
  {
    printf("Connection with Current User Closed\n");
    printf("Server Still Active...\n");
    exit(EXIT_SUCCESS);
  }
  return msg;
}

void snd(int sock, char *msg) 			
{
    //function for sending message to client
    
    int sz = strlen(msg);
    write(sock, &sz, sizeof(int));
    int msg_sz = sz*sizeof(char);
    write(sock, msg, msg_sz);
    
    // first size is sent, then the string is sent, so that recieving becomes simple
}


char * func(char* line, int n)						// extract (num)th field from line which seperated by "," token 
{ 
    char *tok = strtok(line, ","); 						
    while (tok != NULL) 
    { 
	if(!--n) return tok; 
        tok = strtok(NULL, ","); 
    } 
}

struct User Auth(int client_num)
{	
								// return user info after authorization of client 
					
	struct User user;
	while(1)
	{
	
		char * user_name, * pass_word;								// receive UserId/username from the client
		snd(client_num, "Enter Your Bank Username");
		user_name = rcv(client_num);

		snd(client_num, "Enter Your Bank Password");						// receive password from the client
		pass_word = rcv(client_num);
				
		struct User user;
		FILE * fp;
		fp = fopen("login.txt", "r");						        // open login.txt file to check whether current user is authorized
		char line[1000];
		while(fgets(line, 1000, fp))
		{
			char * c1, *c2, *c3;							// col1, 2, 3 correspond field format of login file (username, password, type)
			char * line1 = strdup(line);
			char * line2 = strdup(line);
			c1 = func(line1, 1);c2 = func(line2, 2);c3 = func(line, 3);
			if(strcmp(c1, user_name)==0 && strcmp(c2, pass_word)==0)                   // Verify Current Client is Authorized or not from login.txt file
			{					
				strcpy(user.userID,user_name);
				user.t = c3[0];
				return user;							        //if username verified return user
			}
		}
		snd(client_num, "Invalid Login Details");			                // send msg to client that the user is invalid
		fclose(fp);
	}
	
    return user;
}

char * bal(FILE * user_file)                                                // for a given userfile, find the latest balance which is found in the last row
{							
	char *line = (char*)malloc(1000*sizeof(char));
	char * last_line = (char*)malloc(1000*sizeof(char));
	while(fgets(line, 1000, user_file))
	{
		strcpy(last_line, line);
	}
	char * balance;
	balance = func(last_line, 3);
	if (!balance)									//if buffer is null that means file is empty so balance is zero
        balance = "0";
	return balance;												// return The final balance
}
int count=0;
char * get_mini_stmt(FILE * user_file)                                               // function to get the bottom 10 (latest) entries of the account statement file.
{							

	char *line = (char*)malloc(10000*sizeof(char));
	char * stmt = (char*)malloc(10000*sizeof(char));

	if (fgets(stmt, 1000, user_file)==0 )
	{
		count = 10;
		return stmt ;
	}

	line = get_mini_stmt(user_file);

	if (count>0)
	{
		strcat(line, stmt);
		count--;
	}

	return line;
}

void client_user(int client, struct User user) // This function correspond to the instance when the client(user) is the customer. 
{			
	char * response;
	snd(client, "Enter '1' to view Main Balance\n Enter '2' for Mini Statement");
	free(response);
	response = rcv(client);
	FILE * user_file;
	user_file = fopen(user.userID, "r");
	while(1)
	{													// The server sends various options to the customer to choose
		fseek(user_file, 0, SEEK_SET);
		if(strcmp(response, "1")==0)
		{
			char * balance = bal(user_file);			// Call function to get the account balance providing the file pointer. returns account balance
			char msg[1000] = "Current Balance in Account: ";
			strcat(msg, balance);
			strcat(msg, "\nPress 1 to view Main Balance\nPress 2 to view Mini Statement:");
			snd(client, msg);
			free(response);
			response = rcv(client);				//recieve response from user
		}
		else if(strcmp(response, "2")==0)
		{
		
			char * stmt = get_mini_stmt(user_file);				// Call function to get the mini statement providing the file pointer. returns mini statement
			char msg[10000] = "Mini Statement:\n";
			strcat(msg, stmt);
			strcat(msg, "Enter '1' to view Main Balance\n Enter '2' for Mini Statement");
			snd(client, msg);
			free(response);
			response = rcv(client);
		}
		else
		{													// Condition when client sends incorrect response.
			snd(client, "Enterd Number was invalid. Please Enter a Correct Response");
			free(response);
			response = rcv(client);
		}
	}
}

void client_police(int client, struct User user)
{			// This function corresponds to the instance when the client(user) is the police.
	char * response;
	snd(client, "Enter Customer_ID");				// Ask the userid/username of the customer from the police.
	free(response);
	response = rcv(client);
	FILE * fp;
	fp = fopen("login.txt", "r");
	while(1)
	{													// Search for the given customer.
		fseek(fp, 0, SEEK_SET);
		char *line = (char*)malloc(1000*sizeof(char));
		int flag = 0;
		while(fgets(line, 1000, fp))
		{				
			char * col1, * col3;
			char * line1 = strdup(line);
			col1 = func(line1, 1);
			col3 = func(line, 3);
			if(strcmp(response, col1)==0 && strcmp(col3, "C")==0)
			{	// When found, open his bank file and print the balance and mini statement.
				FILE * user_file;
				user_file = fopen(col1, "r");
				char * balance = bal(user_file);
				fseek(user_file, 0, SEEK_SET);
				char * mini_stmt = get_mini_stmt(user_file);
				char msg[10000] = "Current Balance in Account is as follows: ";
				strcat(msg, balance);
				strcat(msg, "\nMini Statement is as follows: \n");
				strcat(msg, mini_stmt);
				strcat(msg, "\nEnter Customer_ID");
				snd(client, msg);
				flag = 1;
				break;
			}
		}
		if(!flag)
		{								// if customer with provided username is not found 
			char * m = "Invalid Customer_ID\nEnter Correct Customer_ID";
			snd(client, m);
		}
		free(response);
		response = rcv(client);
	}
}

void client_admin(int client, struct User user)
{	// This function correspond to the instance when the client(user) is the customer.
	
	char * response;
	snd(client, "Enter Customer ID");		//Ask admin for the customer ID
	free(response);
	response = rcv(client);
	FILE * fp;
	fp = fopen("login.txt", "r");
	while(1)
	{
		fseek(fp, 0, SEEK_SET);
		char *line = (char*)malloc(1000*sizeof(char));
		int flag = 0;
		while(fgets(line, 1000, fp)){				// Search for the customer
			char * col1, * col3;
			char * line1 = strdup(line);
			col1 = func(line1, 1);
			col3 = func(line, 3);
			if(strcmp(response, col1)==0 && strcmp(col3, "C")==0)
			{		// When found, give admin folowing options
				flag = 1;
				snd(client, "Choose transaction type:\n1) Credit\n2) Debit\n3) Choose Another Customer  ");	
				while(1){
					FILE * user_file;
					user_file = fopen(col1, "r");
					char * balance = bal(user_file);
					fseek(user_file, 0, SEEK_SET);
					free(response);
					response = rcv(client);
					fclose(user_file);
					if(strcmp(response, "3")==0)
					{				//when admin wants to update multiple transactions for other users as well
						snd(client, "Enter Customer_ID");
						break;
					}
					else if(strcmp(response, "1")==0)
					{
						snd(client, "Enter the Amount:");
						free(response);
						response = rcv(client);

						if (atoi(response) <= 0)			//maintaining underflow amount to be credited can't be less than 0
						{
							snd(client, "Invalid Amount\nChoose transaction type:\n1) Credit\n2) Debit\n3) Choose Another Customer  ");	
							continue;
						}

						char * new_balance = (char*)malloc(10*sizeof(char));
						char * current_date = (char*)malloc(12*sizeof(char));
						//Current Date/Time
						time_t t = time(NULL);
						struct tm tm = *localtime(&t);
						sprintf(current_date, "%d/%d/%d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
						//Date time end
						sprintf(new_balance, "%d", atoi(balance) + atoi(response));
						char msg[10000];									// msg is to be the new entry in the customer file
						strcat(msg, current_date);							// It contains today's date, transaction type, and final balance
						strcat(msg, ",");
						strcat(msg, "Credit");
						strcat(msg, ",");
						strcat(msg, new_balance);
						strcat(msg, ",\n");
						user_file = fopen(col1, "a");
						fprintf(user_file, "%s", msg);
						msg[0]= '\0';
						fclose(user_file);
						snd(client, "Updated Successfully\nChoose transaction type:\n1) Credit\n2) Debit\n3) Choose Another Customer  ");
					}
					else if(strcmp(response, "2")==0)
					{
						snd(client, "Enter the Amount:");
						free(response);
						response = rcv(client);
						if (atoi(response) <= 0)
						{
							snd(client, "Invalid Amount\nChoose transaction type:\n1) Credit\n2) Debit\n3) Choose Another Customer  ");	
							continue;
						}
						char * new_balance = (char*)malloc(10*sizeof(char));
						char * current_date = (char*)malloc(12*sizeof(char));
						//Current Date/Time
						time_t t = time(NULL);
						struct tm tm = *localtime(&t);
						sprintf(current_date, "%d/%d/%d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
						//Date time end
						if(atoi(balance) >= atoi(response)){							// when the account have sufficient balance
							char * new_balance = (char*)malloc(10*sizeof(char));
							sprintf(new_balance, "%d", atoi(balance) - atoi(response));
							char msg[10000];								// msg is to be the new entry in the customer file
							strcat(msg, current_date);						// It contains today's date, transaction type, and final balance
							strcat(msg, ",");
							strcat(msg, "Debit");
							strcat(msg, ",");
							strcat(msg, new_balance);
							strcat(msg, ",\n");
							user_file = fopen(col1, "a");
							fprintf(user_file, "%s", msg);
							msg[0]= '\0';
							fclose(user_file);
							snd(client, "Successfully Updated \nChoose transaction type:\n1) Credit\n2) Debit\n3) Choose Another Customer  ");
						}
						else{
																//condition when the intended debit amount is more than the balance 
							snd(client, "Insufficient Balance\nChoose type of Transaction:\n1) Credit\n2) Debit\n3) Choose Another Customer  ");
						}
					}
					else
					{												// When the admin chooses none of the given options
						snd(client, "Invalid Option.\nChoose type of Transaction:\n1) Credit\n2) Debit\n3) Choose Another Customer  ");

					}
				}
				break;
			}
		}
		if(!flag)
		{											// When the given customer is not found in login.txt file or his type is not 'customer'
			snd(client, "Customer ID not present in Records. \nEnter Customer_ID ");
		}
		free(response);
		response = rcv(client);
	}
}

int main(int argc, char const *argv[])
{
    if(argc<2)
    {
         // to handle improper command line arguments
         
         printf("Port Number not provided in the command line\n");
         cmd_argm_format();
         terminate_msg();
         exit(0);  //program terminated
     }
     
     if(argc>2)
     {
	 // to handle improper command line arguments
	    
	 printf("Extra Information Provided or the Information Provided is not in Proper Format (in the command line)\n");
	 cmd_argm_format();
	 terminate_msg();
	 exit(0);   //program terminated
     }
     
     
    int Server_Port_No = atoi(argv[1]);								        // The port of the server is taken from command line terminal
    
    printf("Port No. Provided Successfully Accepted\n");
    
    int server_socket = 0;                                                   // server_socket is the socket of server
    int client_socket = 0; 				                       // client_socket is the socket of the client
    
    server_socket = socket(AF_INET, SOCK_STREAM, 0);                          //creating server socket
                                                                             
    if(server_socket < 0) 		
    { 
        // When the socket creation was not successful 
        printf("Error while Creating Socket\n");
        shutdown(server_socket,SHUT_WR);    //to close socket gracefully
      	printf("\nSocket Closed Gracefully.\n");
    	terminate_msg();
    	exit(0);   //program terminated
    }
    
    printf("Server Socket Created Successfully\n");
    
    struct sockaddr_in add = {0};                                            //built in struct Data Structure in header file <netinet/in.h> 
    struct sockaddr_in client_addr = {0}; 
    
    add.sin_family = AF_INET;                                                //specifying the fields in the struct
    add.sin_addr.s_addr = INADDR_ANY;                                        //specifying the fields in the struct
    add.sin_port = htons(Server_Port_No);                                    //specifying the fields in the struct
    
    int bind_flag = 0;
    bind_flag = bind(server_socket,(struct sockaddr*) &add, sizeof(add));    // Forcefully attaching socket to the given port 
   
    if(bind_flag<0) 	 
    { 
        printf("Binding Not Successful\n");                                  //Port Not Available or Port is Busy
    	shutdown(server_socket,SHUT_WR);    //to close socket gracefully
      	printf("\nSocket Closed Gracefully.\n");
    	terminate_msg();
    	exit(0);   //program terminated
    }
    
    printf("Binding Done Successfully\n"); 

    int backlog = 6;                                                         // backlog refers to the maximum number of pending connections that wait in the queue for sock
    int listen_flag = listen(server_socket, backlog);                        // listen(wait) for initiation from a client 
    
    if (listen_flag < 0) 
    { 
        //Error in listen() function
        printf("Problem while Listening\n");
        shutdown(server_socket,SHUT_WR);    //to close socket gracefully
      	printf("\nSocket Closed Gracefully.\n");                                  
	terminate_msg();
    	exit(0);   //program terminated
    } 
    
    
    
    int client_add_sz = sizeof(client_addr);  
    
    while(1)
    {
    	printf("Server Listening for Client Requests .........\n");
    	client_socket = accept(server_socket, (struct sockaddr*) &client_addr, &client_add_sz);    	
        if (client_socket < 0) 
        { 
                //Error while accepting
		printf("Problem while Accepting\n"); 
		shutdown(server_socket,SHUT_WR);    //to close socket gracefully
      		printf("\nSocket Closed Gracefully.\n");                                 
	    	terminate_msg();
	    	exit(0);   //program terminated
        }
        printf("Client Request Found and Accepted\n");
        switch(fork())
        {
		case -1:
			printf("Child Process Error\n");
			break;
		case 0:
			close(server_socket);
		
			struct User user;
		
			printf("User Authorization Intiaited.....\n");
		
			user = Auth(client_socket);					       // Initiate the message exchange corresponding to User Login. 
		
			printf("User Identified, reply sent to client, awaiting client reply.....\n");
		// seperate fucntions have been implemented for different type of users
		
			switch(user.t)
			{
				case 'C':
				client_user(client_socket, user);break;                      // Type 'C' is for the regular customer, Start customer message exchange.
				case 'P':
				client_police(client_socket, user);break;                    // Type 'P' is for the police, Start Police message exchange.
				case 'A':
				client_admin(client_socket, user);break;                     // Type 'A' is for the bank admin, Start Admin message exchange.
				default:
				printf("Fault in User Information, Refer to admin");break;   // Impossible case
			}
			
			exit(EXIT_SUCCESS);
			break;
			
		default:
			
			close(client_socket);
			break;
		
	}                                           
        
    }
    return 0; 
    //end of program
}
